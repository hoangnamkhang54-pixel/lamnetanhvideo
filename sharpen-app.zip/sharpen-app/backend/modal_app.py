"""
Backend "Làm nét ảnh/video" — chạy trên Modal (serverless GPU T4).

Deploy:
    pip install modal
    modal setup                # đăng nhập tài khoản Modal lần đầu
    modal deploy modal_app.py

Sau khi deploy, Modal in ra 1 URL dạng:
    https://<username>--sharpen-api.modal.run
Copy URL đó vào biến API_BASE trong frontend/index.html.

Kiến trúc:
- POST /submit   -> nhận file (ảnh/video) + độ phân giải mong muốn, trả job_id,
                     rồi chạy xử lý ở background (Modal Function riêng, có GPU).
- GET  /status/{job_id} -> trả trạng thái để frontend poll mỗi 5s.
- Kết quả xử lý được lưu vào Modal Volume và trả về qua GET /result/{job_id}.
"""

import io
import os
import uuid
import subprocess
from pathlib import Path

import modal

app = modal.App("sharpen-api")

# ---------------------------------------------------------------------------
# Image (môi trường) chứa PyTorch + Real-ESRGAN + ffmpeg (có vidstab để chống rung)
# ---------------------------------------------------------------------------
image = (
    modal.Image.debian_slim(python_version="3.11")
    .apt_install("ffmpeg", "libgl1", "libglib2.0-0", "libvidstab-dev")
    .pip_install("numpy<2")
    # Pin đúng cặp torch/torchvision còn giữ module functional_tensor mà basicsr cần
    # (bản mới hơn đã xoá module này khiến basicsr crash lúc import).
    .pip_install(
        "torch==2.1.2",
        "torchvision==0.16.2",
        index_url="https://download.pytorch.org/whl/cu121",
    )
    .pip_install(
        "opencv-python-headless",
        "pillow",
        "python-multipart",
        "fastapi[standard]",
    )
    .pip_install("basicsr==1.4.2", "realesrgan==0.3.0")
)

volume = modal.Volume.from_name("sharpen-jobs", create_if_missing=True)
JOBS_DIR = "/jobs"

# job_id -> {"status":..., "progress":..., "step":..., "result_path":...}
job_store = modal.Dict.from_name("sharpen-job-status", create_if_missing=True)

RES_TARGETS = {
    "1080p": 1080,
    "2k": 1440,
    "4k": 2160,
    "8k": 4320,
}


# ---------------------------------------------------------------------------
# Hàm xử lý ẢNH — chạy trên GPU T4
# ---------------------------------------------------------------------------
@app.function(image=image, gpu="T4", volumes={JOBS_DIR: volume}, timeout=600)
def process_image(job_id: str, target_height: int):
    import cv2
    import numpy as np
    from realesrgan import RealESRGANer
    from basicsr.archs.rrdbnet_arch import RRDBNet

    job_store[job_id] = {"status": "processing", "progress": 40, "step": "Nạp mô hình AI"}

    in_path = f"{JOBS_DIR}/{job_id}/input"
    out_dir = Path(f"{JOBS_DIR}/{job_id}")
    out_path = out_dir / "output.png"

    img = cv2.imread(in_path, cv2.IMREAD_COLOR)
    h, w = img.shape[:2]
    scale = max(2, min(8, round(target_height / h))) if h < target_height else 2

    model = RRDBNet(num_in_ch=3, num_out_ch=3, num_feat=64, num_block=23, num_grow_ch=32, scale=4)
    upsampler = RealESRGANer(
        scale=4,
        model_path="https://github.com/xinntao/Real-ESRGAN/releases/download/v0.1.0/RealESRGAN_x4plus.pth",
        model=model,
        tile=256,
        tile_pad=10,
        pre_pad=0,
        half=True,
    )

    job_store[job_id] = {"status": "processing", "progress": 65, "step": "AI đang phục hồi chi tiết & làm nét"}
    restored, _ = upsampler.enhance(img, outscale=scale)

    # Nếu ảnh ra vẫn nhỏ hơn độ phân giải mục tiêu, resize thêm bằng Lanczos (giữ nét, không mờ)
    rh, rw = restored.shape[:2]
    if rh < target_height:
        factor = target_height / rh
        restored = cv2.resize(restored, (int(rw * factor), target_height), interpolation=cv2.INTER_LANCZOS4)

    # Ghi PNG không nén mất dữ liệu (lossless)
    cv2.imwrite(str(out_path), restored, [cv2.IMWRITE_PNG_COMPRESSION, 3])
    volume.commit()

    job_store[job_id] = {
        "status": "done",
        "progress": 100,
        "step": "Hoàn tất",
        "result_path": str(out_path),
        "content_type": "image/png",
    }


# ---------------------------------------------------------------------------
# Hàm xử lý VIDEO — tách khung hình, làm nét từng khung, rồi chống rung kiểu gimbal
# ---------------------------------------------------------------------------
@app.function(image=image, gpu="T4", volumes={JOBS_DIR: volume}, timeout=1800)
def process_video(job_id: str, target_height: int):
    import cv2
    from realesrgan import RealESRGANer
    from basicsr.archs.rrdbnet_arch import RRDBNet

    job_dir = Path(f"{JOBS_DIR}/{job_id}")
    in_path = job_dir / "input"
    frames_dir = job_dir / "frames"
    frames_out_dir = job_dir / "frames_out"
    frames_dir.mkdir(exist_ok=True)
    frames_out_dir.mkdir(exist_ok=True)

    job_store[job_id] = {"status": "processing", "progress": 35, "step": "Tách khung hình video"}
    subprocess.run(
        ["ffmpeg", "-y", "-i", str(in_path), f"{frames_dir}/%06d.png"],
        check=True, capture_output=True,
    )

    model = RRDBNet(num_in_ch=3, num_out_ch=3, num_feat=64, num_block=23, num_grow_ch=32, scale=4)
    upsampler = RealESRGANer(
        scale=4,
        model_path="https://github.com/xinntao/Real-ESRGAN/releases/download/v0.1.0/RealESRGAN_x4plus.pth",
        model=model, tile=256, tile_pad=10, pre_pad=0, half=True,
    )

    frame_files = sorted(frames_dir.glob("*.png"))
    total = len(frame_files)
    for i, f in enumerate(frame_files):
        img = cv2.imread(str(f), cv2.IMREAD_COLOR)
        h = img.shape[0]
        scale = max(2, min(4, round(target_height / h))) if h < target_height else 2
        restored, _ = upsampler.enhance(img, outscale=scale)
        cv2.imwrite(str(frames_out_dir / f.name), restored)
        if i % 10 == 0:
            pct = 35 + int(35 * (i / max(1, total)))
            job_store[job_id] = {"status": "processing", "progress": pct, "step": f"Đang làm nét khung {i}/{total}"}

    # Ghép lại thành video (giữ khung hình gốc, chất lượng cao, gần lossless)
    job_store[job_id] = {"status": "processing", "progress": 75, "step": "Ghép khung hình thành video"}
    merged_path = job_dir / "merged.mp4"
    probe = subprocess.run(
        ["ffprobe", "-v", "0", "-of", "csv=p=0", "-select_streams", "v:0",
         "-show_entries", "stream=r_frame_rate", str(in_path)],
        capture_output=True, text=True,
    )
    fps = probe.stdout.strip() or "30"
    subprocess.run(
        ["ffmpeg", "-y", "-framerate", fps, "-i", f"{frames_out_dir}/%06d.png",
         "-i", str(in_path), "-map", "0:v:0", "-map", "1:a?",
         "-c:v", "libx264", "-preset", "slow", "-crf", "14",
         "-pix_fmt", "yuv420p", "-c:a", "copy", str(merged_path)],
        check=True, capture_output=True,
    )

    # Chống rung kiểu gimbal bằng bộ lọc vidstab 2 bước của ffmpeg
    job_store[job_id] = {"status": "stabilizing", "progress": 92, "step": "Ổn định khung hình (gimbal)"}
    transforms_path = job_dir / "transforms.trf"
    final_path = job_dir / "output.mp4"

    subprocess.run(
        ["ffmpeg", "-y", "-i", str(merged_path),
         "-vf", f"vidstabdetect=shakiness=6:accuracy=15:result={transforms_path}",
         "-f", "null", "-"],
        check=True, capture_output=True,
    )
    subprocess.run(
        ["ffmpeg", "-y", "-i", str(merged_path),
         "-vf", f"vidstabtransform=input={transforms_path}:smoothing=30:zoom=0:optzoom=1,unsharp=5:5:0.4",
         "-c:v", "libx264", "-preset", "slow", "-crf", "16",
         "-c:a", "copy", str(final_path)],
        check=True, capture_output=True,
    )
    volume.commit()

    job_store[job_id] = {
        "status": "done",
        "progress": 100,
        "step": "Hoàn tất",
        "result_path": str(final_path),
        "content_type": "video/mp4",
    }


# ---------------------------------------------------------------------------
# Web API (FastAPI) — /submit, /status/{id}, /result/{id}
# ---------------------------------------------------------------------------
@app.function(image=image, volumes={JOBS_DIR: volume})
@modal.asgi_app()
def web():
    from fastapi import FastAPI, UploadFile, File, Form
    from fastapi.responses import JSONResponse, FileResponse
    from fastapi.middleware.cors import CORSMiddleware

    api = FastAPI()
    api.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # đổi thành domain GitHub Pages của bạn khi lên production
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @api.post("/submit")
    async def submit(file: UploadFile = File(...), resolution: str = Form("1080p"),
                      is_video: str = Form("0")):
        job_id = uuid.uuid4().hex[:12]
        job_dir = Path(f"{JOBS_DIR}/{job_id}")
        job_dir.mkdir(parents=True, exist_ok=True)

        job_store[job_id] = {"status": "uploading", "progress": 10, "step": "Đang tải ảnh lên"}
        content = await file.read()
        with open(job_dir / "input", "wb") as f:
            f.write(content)
        volume.commit()

        target_h = RES_TARGETS.get(resolution, 1080)
        if is_video == "1":
            process_video.spawn(job_id, target_h)
        else:
            process_image.spawn(job_id, target_h)

        return {"job_id": job_id}

    @api.get("/status/{job_id}")
    async def status(job_id: str):
        data = job_store.get(job_id)
        if not data:
            return JSONResponse({"status": "error", "message": "job không tồn tại"}, status_code=404)
        if data.get("status") == "done":
            data = dict(data)
            data["result_url"] = f"/result/{job_id}"
        return data

    @api.get("/result/{job_id}")
    async def result(job_id: str):
        data = job_store.get(job_id)
        if not data or data.get("status") != "done":
            return JSONResponse({"error": "chưa có kết quả"}, status_code=404)
        return FileResponse(data["result_path"], media_type=data["content_type"])

    return api
