# Làm Nét Ảnh/Video — Hướng dẫn triển khai

Hệ thống gồm 3 phần:

```
frontend/      → trang web giao diện (deploy qua GitHub Pages)
backend/       → xử lý AI, chạy trên Modal (serverless, GPU T4)
ios-wrapper/   → app iOS bọc WebView, build thành .ipa qua GitHub Actions → cài bằng TrollStore
```

## 1. Deploy backend (Modal)

```bash
pip install modal
modal setup                       # đăng nhập / tạo tài khoản Modal (có free tier GPU)
cd backend
modal deploy modal_app.py
```

Modal sẽ in ra một URL dạng:
```
https://<username>--sharpen-api-web.modal.run
```
Copy URL này.

> Lưu ý: lần chạy đầu tiên sẽ chậm hơn vì Modal phải tải model Real-ESRGAN (~65MB) và
> dựng container GPU. Các lần sau container được cache lại (cold start ngắn hơn).

## 2. Deploy frontend (GitHub Pages)

1. Mở `frontend/index.html`, sửa dòng:
   ```js
   const API_BASE = "https://YOUR-MODAL-USERNAME--sharpen-api.modal.run";
   ```
   thành URL Modal bạn vừa lấy ở bước 1.
2. Push thư mục `frontend/` lên một repo GitHub, ví dụ `sharpen-app`.
3. Vào **Settings → Pages**, chọn nhánh chứa `index.html`, bấm Save.
4. Sau vài phút bạn sẽ có URL dạng:
   `https://<github-username>.github.io/sharpen-app/`

## 3. Đóng gói .ipa để cài bằng TrollStore

Vì việc biên dịch app iOS bắt buộc phải chạy trên máy macOS có Xcode (Apple không cho
build trên Linux/Windows), phần này dùng **GitHub Actions với macOS runner** để build hộ —
bạn không cần máy Mac, không cần tài khoản Apple Developer trả phí (TrollStore không cần
chữ ký thật vì nó tận dụng lỗ hổng CoreTrust để cài app "fake-signed").

1. Mở `ios-wrapper/Sources/SharpenApp/App.swift`, sửa dòng:
   ```swift
   let APP_URL = URL(string: "https://YOUR-GITHUB-USERNAME.github.io/sharpen-app/")!
   ```
   thành URL GitHub Pages ở bước 2.
2. Push toàn bộ thư mục `ios-wrapper/` và `.github/workflows/build-ipa.yml` lên repo GitHub.
3. Vào tab **Actions** của repo → chọn workflow **"Build unsigned IPA (TrollStore)"** →
   **Run workflow**.
4. Đợi build xong (~3–5 phút), tải file `LamNetAnh-ipa` ở mục **Artifacts**, giải nén ra
   `LamNetAnh.ipa`.
5. Chuyển file `.ipa` vào iPhone (AirDrop, iCloud Drive, cáp,...), mở bằng **TrollStore** →
   **Install**.

## Ghi chú kỹ thuật

- **Ảnh**: xử lý bằng Real-ESRGAN (x4plus), sau đó resize Lanczos nếu cần đạt đúng độ phân
  giải mục tiêu (1080p/2K/4K/8K). Xuất PNG lossless để không bị nén ép mờ lại.
- **Video**: tách khung hình → làm nét từng khung bằng Real-ESRGAN → ghép lại bằng ffmpeg
  (CRF thấp, gần lossless) → chạy 2 bước `vidstabdetect` + `vidstabtransform` của ffmpeg để
  làm mượt chuyển động giống quay bằng gimbal.
- **Không giới hạn dung lượng file** ở phía giao diện — nhưng thực tế vẫn bị giới hạn bởi:
  mạng di động/wifi của người dùng, và timeout của Modal function (hiện đặt 600s cho ảnh,
  1800s cho video — có thể tăng thêm trong `modal_app.py` nếu cần xử lý video rất dài).
- Endpoint `/submit` hiện cho phép CORS `*` để dễ test — trước khi công khai app, nên đổi
  `allow_origins` trong `modal_app.py` thành đúng domain GitHub Pages của bạn.
