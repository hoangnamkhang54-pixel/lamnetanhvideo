import SwiftUI
import WebKit

@main
struct SharpenIOSApp: App {
    var body: some Scene {
        WindowGroup {
            WebContainerView()
                .ignoresSafeArea()
                .statusBar(hidden: false)
        }
    }
}

/// URL trang web "Làm nét ảnh/video" của bạn, deploy qua GitHub Pages.
/// Đổi thành link GitHub Pages thật sau khi bạn publish frontend/index.html.
let APP_URL = URL(string: "https://YOUR-GITHUB-USERNAME.github.io/sharpen-app/")!

struct WebContainerView: UIViewRepresentable {
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.scrollView.bounces = false
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 10/255, green: 11/255, blue: 13/255, alpha: 1)
        webView.load(URLRequest(url: APP_URL))
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
